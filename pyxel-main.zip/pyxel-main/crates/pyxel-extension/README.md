# pyxel-extension

Python extension module for [Pyxel](https://github.com/kitao/pyxel), a retro game engine for Python.
